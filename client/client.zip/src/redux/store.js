import { createStore, applyMiddleware, combineReducers } from 'redux';
import { thunk } from 'redux-thunk';
import { authReducer } from './reducers/authReducer';
import locationReducer from "./reducers/locationReducer";
import searchReducer from './reducers/searchReducer';

const rootReducer = combineReducers({
  auth: authReducer,
  locations: locationReducer,
  search:searchReducer
});

const store = createStore(rootReducer, applyMiddleware(thunk));

export default store;
