import { toast } from 'react-toastify';
import axios from 'axios';

// Admin Login Action
export const loginAdmin = (username, password) => async (dispatch) => {
  try {
    const response = await axios.post(`${process.env.REACT_APP_API_URL}/auth/admin-login`, {
      username,
      password,
    });

    if (response.status === 200) {
      const { token, message ,userType  } = response.data;
      dispatch({
        type: 'LOGIN_SUCCESS',
        payload: token,
      });
      toast.success(message || 'Login successful!');
      return { success: true, token , userType};
    }
  } catch (error) {
    const errorMessage = error.response?.data?.message || 'Login failed!';
    return { success: false, message: errorMessage };
  }
};

// Forgot Password Action
export const forgotPassword = (email) => async (dispatch) => {
  try {
    const response = await axios.post(`${process.env.REACT_APP_API_URL}/api/admin/forgot-password`, { email });

    if (response.status === 200) {
      const message = response.data.message || 'Reset link sent successfully';
      return { success: true, message };
    }
  } catch (error) {
    const errorMessage = error.response?.data?.message || 'Password reset failed';
    toast.error(errorMessage);
    return { success: false, message: errorMessage };
  }
};
