import React from 'react';
import './PopularBikes.css'; 

const bikes = [
    'Honda Activa',
    'Pulsar 150',
    'Royal Enfield 350 Classic',
    'Avenger 220 Street',
    'Bajaj CT 100',
    'Yamaha FZ',
    'Honda Dio',
    'Avenger 220 Cruise',
    'Dominar 400 ABS',
    'Pulsar NS 200',
  ];
const PopularBikes = () => (
 
    <section className="popular-bikes section">
    <h2 className="heading">Popular Bikes for Rent</h2>
    <div className="bikes-container">
      {bikes.map((bike, index) => (
        <div key={index} className="bike-item">
          {bike}
        </div>
      ))}
    </div>
  </section>
);

export default PopularBikes;
