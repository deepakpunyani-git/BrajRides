import React from 'react';
import { Navigate } from 'react-router-dom';
import { isAdminAuthenticated } from '../utils/authUtils';

const PrivateRouteAdmin = ({ element }) => {
  return isAdminAuthenticated() ? element : <Navigate to="/admin/login" />;
};

export default PrivateRouteAdmin;
