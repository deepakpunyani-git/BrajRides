import { Link, useLocation } from 'react-router-dom';
import React, { useEffect, useState } from 'react';
import { Navbar, Nav, Container, Button } from 'react-bootstrap';
import './Header.css'; 

const Header = () => {
  const [scrolling, setScrolling] = useState(false);
  const location = useLocation(); // Get the current location

  const handleScroll = () => {
    const isScrolled = window.scrollY > 50; // Adjust the scroll position as needed
    setScrolling(isScrolled);
  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Helper function to check if the current path matches the link
  const isActive = (path) => {
    return location.pathname === path;
  };

  return (
    <Navbar bg={scrolling ? "light" : "white"} expand="lg" className={`py-3 header-navbar ${scrolling ? 'scrolled' : ''}`}>
      <Container>
        <Navbar.Brand as={Link} to="/" className="d-flex align-items-center mx-auto">
          <img 
            src={`${process.env.PUBLIC_URL}/logo.png`}
            width="50"
            height="50"
            className="d-inline-block align-top"
            alt="BrajRides Logo"
          />
          <div className="ms-2">BrajRides</div>
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="basic-navbar-nav" />

        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mx-auto d-flex align-items-center">
          <Nav.Link 
              as={Link} 
              to="/" 
              className={`${isActive('/') ? 'active' : ''}`}>
              <Button variant="link">HOME</Button>
            </Nav.Link>
            <Nav.Link 
              as={Link} 
              to="/about-us" 
              className={`${isActive('/about-us') ? 'active' : ''}`}>
              <Button variant="link">ABOUT US</Button>
            </Nav.Link>
            <Nav.Link 
              as={Link} 
              to="/pricing" 
              className={` ${isActive('/pricing') ? 'active' : ''}`}>
              <Button variant="link">PRICING</Button>
            </Nav.Link>

            <Nav.Link 
              as={Link} 
              to="/locations" 
              className={`${isActive('/locations') ? 'active' : ''}`}>
              <Button variant="link">LOCATIONS</Button>
            </Nav.Link>
            <Nav.Link 
              as={Link} 
              to="/contactUs" 
              className={`${isActive('/contactUs') ? 'active' : ''}`}>
              <Button variant="link">CONTACT US</Button>
            </Nav.Link>
            <Nav.Link 
              as={Link} 
              to="/login" 
              className={`${isActive('/login') ? 'active' : ''}`}>
              <Button variant="primary" className="ride-now-btn">LOGIN/SIGNUP</Button>
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
};

export default Header;
