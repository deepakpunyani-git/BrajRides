import React, { useState } from 'react';
import { Container, Row, Col, Form, Button, Card, Toast, ToastContainer } from 'react-bootstrap';
import loginImage from '../assets/login-image.jpg';

const Login = () => {
    const [email, setEmail] = useState('');
    const [otp, setOtp] = useState('');
    const [isOtpSent, setIsOtpSent] = useState(false);
    const [isVerified, setIsVerified] = useState(false);
    const [toastMessage, setToastMessage] = useState('');
    const [showToast, setShowToast] = useState(false);
    const [toastType, setToastType] = useState(''); // 'success' or 'error'

    // Show toast messages
    const showCustomToast = (message, type) => {
        setToastMessage(message);
        setToastType(type);
        setShowToast(true);
    };

    // Handle email submission for OTP
    const handleEmailSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('/api/send-otp', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email })
            });
            const data = await response.json();
            if (data.success) {
                setIsOtpSent(true);
                showCustomToast('OTP sent successfully!', 'success');
            } else {
                showCustomToast(data.message, 'error');
            }
        } catch (err) {
            showCustomToast('Error sending OTP. Please try again.', 'error');
        }
    };

    // Handle OTP verification
    const handleOtpSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('/api/verify-otp', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, otp })
            });
            const data = await response.json();
            if (data.success) {
                setIsVerified(true);
                showCustomToast('OTP verified successfully! You are now logged in.', 'success');
            } else {
                showCustomToast(data.message, 'error');
            }
        } catch (err) {
            showCustomToast('Error verifying OTP. Please try again.', 'error');
        }
    };


    return (
        <Container className="login-container d-flex justify-content-center align-items-center my-5">
            <Row className="login-row shadow-lg">
                <Col md={6} className="p-0">
                    <img src={loginImage} alt="Login" className="login-image" />
                </Col>
                <Col md={6} className="p-5 d-flex flex-column justify-content-center">
                    <Card className="border-0">
                        <Card.Body>
                            <h2 className="text-center mb-4">Welcome Back!</h2>
                            {!isOtpSent ? (
                                <Form onSubmit={handleEmailSubmit}>
                                    <Form.Group controlId="formBasicEmail">
                                        <Form.Label>Email address</Form.Label>
                                        <Form.Control
                                            type="email"
                                            placeholder="Enter your email"
                                            value={email}
                                            onChange={(e) => setEmail(e.target.value)}
                                        />
                                    </Form.Group>
                                    <Button variant="primary" type="submit" className="w-100 mt-4">
                                        Send OTP
                                    </Button>
                                </Form>
                            ) : (
                                <Form onSubmit={handleOtpSubmit}>
                                    <Form.Group controlId="formBasicOtp">
                                        <Form.Label>Enter OTP</Form.Label>
                                        <Form.Control
                                            type="text"
                                            placeholder="Enter the OTP sent to your email"
                                            value={otp}
                                            onChange={(e) => setOtp(e.target.value)}
                                        />
                                    </Form.Group>
                                    <Button variant="primary" type="submit" className="w-100 mt-4">
                                        Verify OTP
                                    </Button>
                                </Form>
                            )}
                            {isVerified && <p className="text-success text-center mt-3">Login Successful!</p>}
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            <ToastContainer position="top-end" className="p-3">
                <Toast onClose={() => setShowToast(false)} show={showToast} delay={3000} autohide bg={toastType}>
                    <Toast.Body>{toastMessage}</Toast.Body>
                </Toast>
            </ToastContainer>
        </Container>
    );
};

export default Login;
