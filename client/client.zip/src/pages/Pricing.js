import React, { useState } from 'react';
import { Container, Row, Col, Form, Card } from 'react-bootstrap';
import { useSelector } from 'react-redux';

// Sample Bike Data
const bikesData = [
  {
    id: 1,
    brand: 'Yamaha',
    model: 'MT-15',
    location: 'Vrindavan',
    dailyPrice: 500,
    weeklyPrice: 3000,
    isElectric: false,
    imageUrl: '/path/to/yamaha-mt15.jpg', // Replace with actual image path
  },
  {
    id: 2,
    brand: 'Hero',
    model: 'Electric Optima',
    location: 'Mathura City',
    dailyPrice: 400,
    weeklyPrice: 2500,
    isElectric: true,
    imageUrl: '/path/to/hero-electric-optima.jpg', // Replace with actual image path
  },
  {
    id: 3,
    brand: 'Honda',
    model: 'Activa',
    location: 'Barsana',
    dailyPrice: 350,
    weeklyPrice: 2100,
    isElectric: false,
    imageUrl: '/path/to/honda-activa.jpg', // Replace with actual image path
  },
  {
    id: 4,
    brand: 'Ather',
    model: '450X',
    location: 'Nandgaon',
    dailyPrice: 600,
    weeklyPrice: 3600,
    isElectric: true,
    imageUrl: '/path/to/ather-450x.jpg', // Replace with actual image path
  },
  // More bike entries...
];

const Pricing = () => {
  const { location, startDate, endDate } = useSelector((state) => state.search);

  const [selectedLocation, setSelectedLocation] = useState('All');

  const handleLocationChange = (e) => {
    setSelectedLocation(e.target.value);
  };

  // Filter the bikes based on selected location
  const filteredBikes = bikesData.filter((bike) =>
    selectedLocation === 'All' ? true : bike.location === selectedLocation
  );

  return (
    <div className="pricing-page">
      <div className="container py-5">
      <h2>Bike Rental Details</h2>
      <p><strong>Location:</strong> {location}</p>
      <p><strong>From:</strong> {startDate}</p>
      <p><strong>To:</strong> {endDate}</p>
    </div>
      <Container className="pricing-container py-5">
        <h2 className="text-center mb-4">Bike Rental Prices</h2>
        <Form.Group controlId="locationFilter" className="mb-4">
          <Form.Label>Filter by Location</Form.Label>
          <Form.Control as="select" value={selectedLocation} onChange={handleLocationChange}>
            <option value="All">All Locations</option>
            <option value="Vrindavan">Vrindavan</option>
            <option value="Mathura City">Mathura City</option>
            <option value="Barsana">Barsana</option>
            <option value="Nandgaon">Nandgaon</option>
          </Form.Control>
        </Form.Group>

        <Row>
          {filteredBikes.length ? (
            filteredBikes.map((bike) => (
              <Col md={4} sm={6} key={bike.id} className="mb-4">
                <Card className="h-100 shadow">
                  <Card.Img variant="top" src={bike.imageUrl} alt={`${bike.brand} ${bike.model}`} />
                  <Card.Body>
                    <Card.Title>{`${bike.brand} ${bike.model}`}</Card.Title>
                    <Card.Text>
                      <strong>Location:</strong> {bike.location}
                      <br />
                      <strong>Daily Price:</strong> ₹{bike.dailyPrice}
                      <br />
                      <strong>Weekly Price:</strong> ₹{bike.weeklyPrice}
                      <br />
                      <strong>Electric:</strong> {bike.isElectric ? 'Yes' : 'No'}
                    </Card.Text>
                  </Card.Body>
                </Card>
              </Col>
            ))
          ) : (
            <p>No bikes available in this location.</p>
          )}
        </Row>
      </Container>
    </div>
  );
};

export default Pricing;
