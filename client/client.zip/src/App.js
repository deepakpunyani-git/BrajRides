import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import AboutUs from './pages/AboutUs';
import Locations from './pages/Locations';
import ContactUs from './pages/ContactUs';
import Login from './pages/Login';
import Pricing from './pages/Pricing';


const AppContent = () => {

  return (
    <>
 <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about-us" element={<AboutUs />} />
        <Route path="/locations" element={<Locations />} />
        <Route path="/contactUs" element={<ContactUs />} />
        <Route path="/login" element={<Login />} />
        <Route path="/pricing" element={<Pricing />} />


      </Routes>

      <Footer />  
      <ToastContainer position="top-right" autoClose={3000} />

        </>
  );
};

const App = () => (
  <Router>
    <AppContent />
  </Router>
);

export default App;
