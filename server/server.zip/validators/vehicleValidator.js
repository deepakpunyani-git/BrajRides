const { body } = require('express-validator');

exports.addRideValidator = [
  body('brand').notEmpty().withMessage('Brand is required'),
  body('model').notEmpty().withMessage('Model is required'),
  body('price').isNumeric().withMessage('Price must be a number'),
  body('type').isIn(['scooty', 'bike']).withMessage('Type must be either scooty or bike'),
  body('location').notEmpty().withMessage('Location is required'),
];

exports.updateRideValidator = [
  body('brand').notEmpty().withMessage('Brand is required'),
  body('model').notEmpty().withMessage('Model is required'),
  body('price').isNumeric().withMessage('Price must be a number'),
  body('type').isIn(['scooty', 'bike']).withMessage('Type must be either scooty or bike'),
  body('location').notEmpty().withMessage('Location is required'),
];
