const { body } = require('express-validator');

// Validator for email login
const emailLoginValidator = [
  body('email').isEmail().withMessage('Please enter a valid email'),
];

const verifyOtpValidator = [
  body('email').isEmail().withMessage('Please enter a valid email'),
  body('otp').isLength({ min: 6, max: 6 }).withMessage('OTP should be 6 digits'),
];

const adminStaffLoginValidator = [
  body('usernameOrEmail').notEmpty().withMessage('Username or email is required'),
  body('password').notEmpty().withMessage('Password is required'),
];

module.exports = {
  emailLoginValidator,
  verifyOtpValidator,
  adminStaffLoginValidator,
};
